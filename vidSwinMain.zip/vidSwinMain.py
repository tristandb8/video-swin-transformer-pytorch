from ast import Num
import torch
import torch.nn as nn
from video_swin_transformer import SwinTransformer3D

model = SwinTransformer3D()
num_classes = 8
# model = nn.Sequential(model, nn.Linear(768, num_classes))
print(model)

dummy_x = torch.rand(1, 3, 10, 224, 224)
logits = model(dummy_x)
print(logits.shape) # torch.Size([1, 768, 3, 7, 7]) [batch, c, time, h, w]
logits1 = torch.nn.functional.adaptive_avg_pool3d(logits, 1)
print(logits1.shape)
logits1 = logits1.flatten(1)
print(logits1.shape) #

